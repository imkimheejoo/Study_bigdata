from flask import Flask,render_template

app = Flask(__name__)
@app.route('/a/<path>') #라우트는 다른라우트를 동시에 제공할 수 있음
@app.route('/<path>')
def hello_world(path=None):
    if path != None:
        return render_template('%s.html' % path)
     #elif path=='ddd':
     #   return render_template('ddd.html')
     #elif path=='t1':
     #   return render_template('t1.html')


@app.route('/')
def index():
    return render_template('study.html')
#@app.route('/')
#def hello_world():
#    return render_template('ddd.html')

@app.route('/a')
def hello_world2():
    return 'hello 문'
if __name__ == '__main__':
    app.run(debug=True)
